const express = require('express');
const path = require('path');
const app = express();
const PORT = 8080;
const mongoose = require('mongoose');
const session = require('express-session');






mongoose.connect('mongodb://localhost:27017/hotelDB')
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.error("MongoDB connection error:", err));


// session middleware
app.use(
  session({
    secret: 'yourSecretKey',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
  })
);

// EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// middlewares
const logger = require('./middlewares/logger');
const errorHandler = require('./middlewares/errorHandler');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');

// Security Middleware
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        "default-src": ["'self'"],
        "script-src": ["'self'"],
        "img-src": ["'self'", "https://source.unsplash.com"],
        "style-src": ["'self'", "'unsafe-inline'"]
      }
    }
  })
);

// Other middlewares
app.use(morgan('dev'));
app.use(cors());
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate Limiting
const limiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 100
});
app.use(limiter);

// Custom logger
app.use(logger);

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// API Routes (login/register logic)
const apiRoutes = require('./api/apiRoutes');
app.use('/api', apiRoutes);

// Page Routes
app.get('/', (req, res) => {
  res.render('home');
});




app.get('/login', (req, res) => {
  res.render('login');
});

app.get('/register', (req, res) => {
  res.render('register');
});

// Dashboard Route
app.get('/dashboard', (req, res) => {
  const user = req.session.user;

  if (!user) {
    return res.redirect('/login');
  }

  res.render('dashboard', { username: user.username });
});



app.get('/guests', (req, res) => {
  res.render('guests');
});

app.post('/contact', async (req, res) => {
    try {
        const { name, email, subject, message } = req.body;
        
        // Create using the model
        await contactModel.create({
            name,
            email,
            subject,
            message
        });

        res.render('home', {
            successMessage: 'Message sent successfully!',
            errorMessage: ''
        });
    } catch (err) {
        console.error('FULL ERROR:', err);
        res.render('home', {
            errorMessage: `Error: ${err.message}`,
            successMessage: ''
        });
    }
});
// Global Error Handler
app.use(errorHandler);

// Start Server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});

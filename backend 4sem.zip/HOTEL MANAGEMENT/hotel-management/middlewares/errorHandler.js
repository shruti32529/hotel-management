const errorHandler = (err, req, res, next) => {
    console.error(`[ERROR] ${err.stack}`); // Log full error details to the console

    const statusCode = err.status || 500; // Use provided status code or default to 500
    const response = {
        error: "Something went wrong!",
        message: err.message || "Internal Server Error"
    };

    // Provide full error stack only in development mode
    if (process.env.NODE_ENV === "development") {
        response.stack = err.stack;
    }

    res.status(statusCode).json(response); // Send error response as JSON
};

module.exports = errorHandler;

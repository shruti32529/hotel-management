const logger = (req, res, next) => {
    const method = req.method; // HTTP method (GET, POST, etc.)
    const url = req.url; // Requested URL
    const ip = req.ip || req.connection.remoteAddress; // Client IP address
    const timestamp = new Date().toISOString(); // Timestamp
    
    console.log(`[${timestamp}] ${method} ${url} - IP: ${ip}`);
    
    const start = Date.now(); // Start time
    res.on('finish', () => { // Log response time when request completes
        const duration = Date.now() - start;
        console.log(`[${timestamp}] ${method} ${url} - Status: ${res.statusCode} - Duration: ${duration}ms`);
    });

    next(); // Call next middleware or route handler
};

module.exports = logger;

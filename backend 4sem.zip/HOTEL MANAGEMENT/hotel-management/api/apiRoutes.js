const express = require('express');
const router = express.Router();

const User = require('../models/user'); 


const Booking = require('../models/Bookings');



const roomsData = [
  {
    name: "Deluxe Room",
    description: "Spacious room with sea view, king-size bed, and balcony.",
    price: "₹3,999/night",
    image: "/images/deluxe-room.jpg"
  },
  {
    name: "Standard Room",
    description: "Cozy room with queen-size bed and modern amenities.",
    price: "₹2,499/night",
    image: "/images/standard-room.jpg"
  },
  {
    name: "Luxury Suite",
    description: "Luxurious suite with a separate living area, king-size bed, and private jacuzzi.",
    price: "₹7,499/night",
    image: "/images/luxury-suite.jpg"
  },
  {
    name: "Family Room",
    description: "A spacious room ideal for families, with two queen-size beds and a comfortable sitting area.",
    price: "₹5,499/night",
    image: "/images/family-room.jpg"
  },
  {
    name: "Presidential Suite",
    description: "An exclusive suite with premium amenities, including a personal butler, large balcony, and full kitchen.",
    price: "₹15,999/night",
    image: "/images/presidential-suite.jpg"
  },
  {
    name: "Ocean View Suite",
    description: "A stunning suite with a panoramic ocean view, a king-size bed, and a luxurious bathtub.",
    price: "₹9,999/night",
    image: "/images/ocean-view-suite.jpg"
  },
  {
    name: "Penthouse Suite",
    description: "The ultimate luxury, featuring a private pool, rooftop terrace, and multiple bedrooms with spectacular city views.",
    price: "₹25,999/night",
    image: "/images/penthouse-suite.jpg"
  }
];


// Handle /rooms route
router.get('/rooms', (req, res) => {
  const username = req.session.user?.username || null;
  res.render('rooms', { rooms: roomsData, username });
});

router.get('/offers', (req, res) => {
    res.render('offers'); 
});


// LOGIN (with MongoDB)
router.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await User.findOne({ username: username.toLowerCase(), password });

        if (!user) {
            return res.status(401).render('login', { error: 'Invalid username or password' });
        }

        req.session.user = { username: user.username };
        res.redirect('/dashboard');
    } catch (error) {
        console.error("Login error:", error);
        res.status(500).render('login', { error: 'Server error during login' });
    }
});

/// REGISTER (with MongoDB)
router.post('/register', async (req, res) => {
    const { name, email, username, password } = req.body;

    // Validate if all fields are provided
    if (!name || !email || !username || !password) {
        return res.status(400).json({ error: "All fields (name, email, username, and password) are required!" });
    }

    try {
        // Check if the username already exists
        const existingUser = await User.findOne({ username: username.toLowerCase() });

        if (existingUser) {
            return res.status(400).json({ error: "Username already exists!" });
        }

        // Create a new user with the provided details
        const newUser = new User({
            name,
            email,
            username: username.toLowerCase(),
            password
        });

        // Save the new user to the database
        await newUser.save();

        res.status(201).json({ success: true, message: "Registration successful!" });
    } catch (error) {
        console.error("Registration error:", error);
        res.status(500).json({ error: "Server error during registration." });
    }
});




// Dashboard
router.get('/dashboard', (req, res) => {
    if (!req.session.user) return res.redirect('/login');
    res.render('dashboard', { username: req.session.user.username });
});
// POST /api/submit-booking
// POST /api/submit-booking (MongoDB version)
router.post('/submit-booking', async (req, res) => {
    const { guestName, email, suite, checkIn, checkOut, service } = req.body;

    try {
        const newBooking = new Booking({
            guestName,
            email,
            suite,
            checkIn,
            checkOut,
            service
        });

        await newBooking.save();
        console.log('Booking saved:', newBooking);
        res.redirect('/dashboard'); // Redirect after successful booking
    } catch (err) {
        console.error('Error saving booking:', err);
        res.status(500).send('Something went wrong while saving the booking.');
    }
});




// Guests
router.get('/guests', (req, res) => {
    if (!req.session.user) return res.redirect('/');
    res.render('guests', { username: req.session.user.username });
});

// Booking Form
router.get('/new-booking', (req, res) => {
    if (!req.session.user) return res.redirect('/');
    res.render('newBooking', { username: req.session.user.username });
});


module.exports = router;

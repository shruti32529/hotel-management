document.getElementById("registerForm").addEventListener("submit", async function(event) {
    event.preventDefault(); // Prevent default form submission

    // Collect the values from the form
    const name = document.getElementById("name").value;  // Get the name value
    const email = document.getElementById("email").value;  // Get the email value
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Check if all fields are filled
    if (!name || !email || !username || !password) {
        alert("All fields are required!");
        return;
    }

    try {
        // Send the data to the server
        const response = await fetch("/api/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ name, email, username, password })  // Send name and email as well
        });

        const data = await response.json(); // Parse the response as JSON

        if (response.ok) {
            alert(data.message);
            window.location.href = "/"; // Redirect to login page
        } else {
            alert(data.error);  // Show error message if registration fails
        }
    } catch (error) {
        console.error("Error during registration:", error);
        alert("An error occurred. Please try again.");
    }
});

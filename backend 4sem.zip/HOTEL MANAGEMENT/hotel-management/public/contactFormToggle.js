// JavaScript for toggling between contact and about us forms
document.getElementById('contactBtn').addEventListener('click', function() {
    document.getElementById('contactFormContainer').style.display = 'block';
    document.getElementById('aboutFormContainer').style.display = 'none';
});

document.getElementById('aboutBtn').addEventListener('click', function() {
    document.getElementById('aboutFormContainer').style.display = 'block';
    document.getElementById('contactFormContainer').style.display = 'none';
});

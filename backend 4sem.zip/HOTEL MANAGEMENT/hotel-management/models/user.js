const mongoose = require('mongoose');

// Define the User schema
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true  // Name is a required field
    },
    email: {
        type: String,
        required: true,  // Email is a required field
        unique: true,    // Email should be unique
        match: [/\S+@\S+\.\S+/, 'Please provide a valid email address.']  // Regex for email validation
    },
    username: {
        type: String,
        required: true,  // Username is a required field
        unique: true     // Username should be unique
    },
    password: {
        type: String,
        required: true  // Password is a required field
    }
});

// Create a model from the schema
const User = mongoose.model('User', userSchema);

// Export the model to use in other files
module.exports = User;
